from django.urls import path

from . import views

urlpatterns = [
    path('country/<cc>/', views.get_country),
    path('state/<cc>/<sc>/', views.get_state),
]
