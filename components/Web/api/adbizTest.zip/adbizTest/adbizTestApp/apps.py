from django.apps import AppConfig


class AdbiztestappConfig(AppConfig):
    name = 'adbizTestApp'
