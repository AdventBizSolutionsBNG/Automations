from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

# Create your views here.

from .models import Country,State

def get_country(request, cc):
    try:
        if request.method == 'GET':
            if cc == "ALL":
                country_list = Country.objects.filter(is_active=True)
            elif cc != "" or cc is not None:
                country_list = Country.objects.filter(is_active=True, country_code=cc)
            print(len(country_list))

            if len(country_list) >0:
                context = {'country_list': country_list }
                template = loader.get_template('country/country.html')
                return HttpResponse(template.render(context, request))
            else:
                output = "Error!!! No Country found with the code:" + cc
                return HttpResponse(output)


    except Exception as e:
        print("--------------->", e)
        output = "Error!!!" + str(e)
        return HttpResponse(output)


def get_state(request, cc, sc):
    try:
        if request.method == 'GET':
            country_id = Country.objects.filter(is_active=True, country_code=cc)
            if country_id is not None:
                if sc == "ALL":
                    state_list = State.objects.filter(country__in = country_id, is_active=True)
                    print(state_list)
                elif sc != "" or sc is not None:
                    state_list = State.objects.filter(country__in = country_id, is_active=True, state_code=sc )

                if len(state_list)>0:
                    context = {'state_list': state_list}
                    template = loader.get_template('state/state.html')
                    return HttpResponse(template.render(context, request))
                else:
                    output = "Error!!! No State found with the code:" + sc
                    return HttpResponse(output)
            else:
                output = "Error!!! No Country found with the code:" + cc
                return HttpResponse(output)

    except Exception as e:
        print(e)
        output = "Error!!!" + str(e)
        return HttpResponse(output)